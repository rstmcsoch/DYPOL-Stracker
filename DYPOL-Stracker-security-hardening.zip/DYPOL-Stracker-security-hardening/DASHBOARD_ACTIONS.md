# Changes that still require account access

## Supabase Auth

Disable new email signups, enable CAPTCHA, enable leaked-password protection, and set an appropriate password length policy.

Verify the Auth settings endpoint reports `disable_signup: true` after changing the Dashboard setting.

## Password reset

Restrict the Supabase Auth redirect URL allowlist to the exact production URL used by the app, rather than a wildcard.

## Database

Run the included migration through the normal Supabase migration pipeline. The FK constraint names should be checked against the hosted schema before applying.

## CI

Set the GitHub Actions repository secret `SUPABASE_DB_URL` if you want the supplied RLS guard to run.
