# DYPOL Stracker security hardening bundle

Target: commit `ffef507` after PR #3, based on the security audit supplied in the conversation.

## Included

- `changes.diff` — targeted source/config changes against the reviewed files.
- `supabase/migrations/20261008000000_security_hardening.sql` — F5 score invariant + F7 composite FK fix.
- `supabase/security/rls_guard.sql` — F6 CI database guard.
- `.github/workflows/rls-guard.yml` — GitHub Actions wrapper for the RLS guard.
- `DASHBOARD_ACTIONS.md` — remaining account-only changes.

## F3 logout caveat

The reviewed `DataContext` maintains a real offline sync queue. Clearing IndexedDB at logout can discard unsynced writes. The source patch clears the user-scoped local cache as requested by the audit, but production behavior should decide whether logout first flushes queued writes or warns the user that pending offline changes will be discarded.

## F2 CSP caveat

The supplied `vercel.json` keeps the existing SPA rewrite and adds headers. The CSP uses `https://*.supabase.co` because the project URL is environment-driven in `VITE_SUPABASE_URL`. For a tighter policy, replace the wildcard with the exact Supabase origin used by the project.

## Manual actions

Public signup, CAPTCHA/leaked-password protection, redirect allowlist verification, hosted DB migration, and GitHub secret configuration require access to the relevant dashboards/accounts.
