-- DYPOL Stracker security/correctness hardening.
-- Review the existing FK constraint names before applying the FK section.

-- F5: reject marks greater than the total.
-- NOT VALID can be chosen instead if you have known historical 60/50 rows that
-- you intentionally want to keep. Validate after cleaning historical data.
alter table public.tests
  drop constraint if exists tests_valid_marks;
alter table public.tests
  add constraint tests_valid_marks
  check (marks_obtained is null or total_marks is null or marks_obtained <= total_marks);

alter table public.test_subject_scores
  drop constraint if exists test_subject_scores_marks_within_range;
alter table public.test_subject_scores
  add constraint test_subject_scores_marks_within_range
  check (marks_obtained is null or total_marks is null or marks_obtained <= total_marks);

alter table public.test_chapter_links
  drop constraint if exists test_chapter_links_marks_within_range;
alter table public.test_chapter_links
  add constraint test_chapter_links_marks_within_range
  check (marks_obtained is null or total_marks is null or marks_obtained <= total_marks);

-- F7: null only chapter_id when its chapter is deleted.
alter table public.daily_tasks
  drop constraint if exists daily_tasks_user_id_chapter_id_fkey;
alter table public.daily_tasks
  add constraint daily_tasks_user_chapter_fkey
  foreign key (user_id, chapter_id)
  references public.chapters (user_id, id)
  on delete set null (chapter_id);

alter table public.study_sessions
  drop constraint if exists study_sessions_user_id_chapter_id_fkey;
alter table public.study_sessions
  add constraint study_sessions_user_chapter_fkey
  foreign key (user_id, chapter_id)
  references public.chapters (user_id, id)
  on delete set null (chapter_id);
